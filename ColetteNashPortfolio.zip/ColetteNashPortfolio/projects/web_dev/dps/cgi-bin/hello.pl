#!/usr/bin/perl
use strict;
print "Content-type: text/html\n\n";
print <<endOfHTML;
<!DOCTYPE html>
<html>
<body>
Hello World!
</body>
</html>
endOfHTML
